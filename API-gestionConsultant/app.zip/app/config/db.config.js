module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "rb_gestconsultant"
};
  