export interface Task {
    id_cons?: number;
    id_cli:string;
    duree:number;
    date:number;
    facture:boolean;
}
